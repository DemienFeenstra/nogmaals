# Print de uren van de dag. Voor de ochtend voeg je 'AM' toe. Voor de middag voeg je 'PM' toe
i = 1
while i <= 11:
        print(i, "am")
        i = i + 1
print(12,"pm")

j = 1
while j <= 11:
        print(j, "pm")
        j = j + 1
print(12,"am")