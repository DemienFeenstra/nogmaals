# Print alle even getallen tussen 20 en 50
i = 20
while i >= 20:
    print(i)
    i = i + 2
    if i == 50:
        break