# Vanaf 30 terugtellen tot de raketlancering. Print elke tel en print de lancering.
i = 30
while i <= 30:
        print(i)
        i = i - 1
        if i == 0:
                break
print("raketlacering succesvol!")