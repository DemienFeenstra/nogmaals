# Tel de cijfers vanaf 50 totdat hun gezamelijke som groter is dan 1000,
# print elk cijfer en de totale som per iteratie.

i = 50
while i <= 1000:
    i = i + 1
    print(i)